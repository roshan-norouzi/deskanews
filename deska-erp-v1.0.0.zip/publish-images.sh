#!/usr/bin/env bash
set -Eeuo pipefail
VERSION="${1:-$(tr -d '[:space:]' < VERSION)}"
PREFIX="${2:-${IMAGE_PREFIX:-}}"
[[ -n "$PREFIX" ]] || { echo 'Usage: IMAGE_PREFIX=ghcr.io/user/deska ./publish-images.sh [version]'; exit 1; }
docker buildx build --platform linux/amd64,linux/arm64 -f apps/api/Dockerfile -t "$PREFIX/api:$VERSION" --push .
docker buildx build --platform linux/amd64,linux/arm64 -f apps/web/Dockerfile -t "$PREFIX/web:$VERSION" --build-arg NEXT_PUBLIC_APP_VERSION="$VERSION" --push .
echo "Published $PREFIX/api:$VERSION and $PREFIX/web:$VERSION"
