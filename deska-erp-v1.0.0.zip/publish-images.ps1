param([string]$Version = ((Get-Content VERSION -Raw).Trim()), [string]$Prefix = $env:IMAGE_PREFIX)
$ErrorActionPreference = 'Stop'
if (-not $Prefix) { throw 'IMAGE_PREFIX را مانند ghcr.io/username/deska تنظیم کنید.' }
docker buildx build --platform linux/amd64,linux/arm64 -f apps/api/Dockerfile -t "$Prefix/api`:$Version" --push .
docker buildx build --platform linux/amd64,linux/arm64 -f apps/web/Dockerfile -t "$Prefix/web`:$Version" --build-arg "NEXT_PUBLIC_APP_VERSION=$Version" --push .
Write-Host "Published $Prefix/api:$Version and $Prefix/web:$Version" -ForegroundColor Green
